import { Component } from '@angular/core';

@Component({
  selector: 'app-add-booking',
  imports: [],
  templateUrl: './add-booking.html',
  styleUrl: './add-booking.css',
})
export class AddBooking {

}
