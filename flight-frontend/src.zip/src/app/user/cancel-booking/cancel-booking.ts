import { Component } from '@angular/core';

@Component({
  selector: 'app-cancel-booking',
  imports: [],
  templateUrl: './cancel-booking.html',
  styleUrl: './cancel-booking.css',
})
export class CancelBooking {

}
