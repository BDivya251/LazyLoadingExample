import { Component } from '@angular/core';

@Component({
  selector: 'app-search-by-email',
  imports: [],
  templateUrl: './search-by-email.html',
  styleUrl: './search-by-email.css',
})
export class SearchByEmail {

}
